## Investigating the Spatial Variability in Soil Geochemical and Colour Properties Across Two Contrasting Land Uses

This manuscript is actively being developed. This work is **very preliminary** at this stage and has not been peer-reviewed and is no not ready for public dissemination.
A preview of the manuscript, including notebooks for analysis, can be found at <https://alexkoiter.ca/spatial-variability-soil-manuscript/>

